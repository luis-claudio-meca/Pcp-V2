<?php require_once "vistas/parte_superior.php" ?>

<img class="mx-auto d-block" src="img/maquina-de-pressao.svg" width="300" height="300" alt="" border="0" align="">

<?php require_once "vistas/parte_inferior.php" ?>