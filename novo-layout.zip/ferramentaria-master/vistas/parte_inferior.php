</div>
<!-- End of Main Content -->

<!-- Footer -->
<footer class="sticky-footer bg-white">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span class="text-success font-weight-bold">Sistema de Manutenção Preventiva do Molde <i class="fas fa-cog text-success"></i></span>
    </div>
  </div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded-circle border-0" href="#page-top">
  <i class="my-2 fas fa-angle-up"></i>
</a>


<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery-3.5.1.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- <script src="vendor/popper/popper.min.js"></script> -->

<script src="js/sweetalert/sweetalert2.all.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="js/sb-admin-2.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>

<!-- datatables JS -->
<script type="text/javascript" src="vendor/datatables/datatables.min.js"></script>

<!-- para usar botões no datatables JS -->
<script type="text/javascript" src="vendor/datatables/datatables.min.js"></script>
<script type="text/javascript" src="vendor/datatables/popper/popper.min.js"></script>
<script src="vendor/datatables/Buttons-1.6.5/js/dataTables.buttons.min.js"></script>
<script src="vendor/datatables/JSZip-2.5.0/jszip.min.js"></script>
<script src="vendor/datatables/pdfmake-0.1.36/pdfmake.min.js"></script>
<script src="vendor/datatables/pdfmake-0.1.36/vfs_fonts.js"></script>
<script src="vendor/datatables/Buttons-1.6.5/js/buttons.html5.min.js"></script>
<script src="vendor/datatables/Responsive-2.2.6/js/dataTables.responsive.js"></script>

<script src="js/datedropper.pro.min.js"></script>


<script src="js/javascript/script.js"></script>


</body>
</html>