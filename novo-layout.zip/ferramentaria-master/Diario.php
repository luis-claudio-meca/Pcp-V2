<?php require_once "vistas/parte_superior.php" ?>

<!--INICIO del cont principal-->
<div class="container">

    <div class="d-none d-xl-block">
        <h2 class="font-weight-bold text-center">Registro Diário</h2>
    </div>
    <div class="d-none d-lg-block d-xl-none">
        <h3 class="rounded mx-auto d-block font-weight-bold text-center">Clientes</h3>
    </div>
    <div class="d-none d-md-block d-lg-none">
        <h4 class="rounded mx-auto font-weight-bold text-center">Clientes</h4>
    </div>
    <div class="d-none d-sm-block d-md-none">
        <h5 class="rounded mx-auto d-block font-weight-bold text-center">Clientes</h5>
    </div>
    <div class="d-block d-sm-none">
        <h5 class="rounded mx-auto d-block font-weight-bold text-center">Clientes</h5>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <button style="float:right" id="btnAdicionarDiario" type="button" class="btn btn-success shadow-sm lift o-hidden" data-toggle="modal"><i class="fas fa-plus"></i>Adicionar Novo</button>
            </div>
            
        </div>   
    </div>
    <br>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card shadow mb-4">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="tabelaDiario"  class="table table-striped table-bordered table-condensed" style="width:100%">
                                <thead class="text-center">
                                    <tr>
                                        <th>Molde</th>
                                        <th>Descrição</th>
                                        <th>Data</th>
                                        <th>Qtd Peças Produzidas</th>
                                        <th>Shots</th>
                                        <th>N° Cavidade</th>
                                        <th>Editar/Excluir</th>
                                     
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--Modal para CRUD-->
    <div class="modal fade" id="modalCRUDDiario" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" data-backdrop="static" data-keyboard="false" aria-hidden="true">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="formDiario">
                    <div class="modal-body row">
                        <div class="form-group col-md-4">
                            <label class="col-form-label font-weight-bold">Molde:</label>
                            <input type="text" class="form-control" autocomplete="off" name="molde" id="molde_">
                        </div>
                        <div class="form-group col-md-4">
                            <label class="col-form-label font-weight-bold">Descricao</label>
                            <input type="text" class="form-control" autocomplete="off" id="descricao">
                        </div>
                        <div class="form-group col-md-4">
                            <label class="col-form-label font-weight-bold">Data</label>
                            <input type="text" class="form-control" autocomplete="off" id="data">
                        </div>
                        <div class="form-group col-md-4">
                            <label class="col-form-label font-weight-bold">Qtd Peças Produzidas</label>
                            <input type="text" class="form-control" autocomplete="off" id="qtd">
                        </div>
                        <div class="form-group col-md-4">
                            <label class="col-form-label font-weight-bold">Shots</label>
                            <input type="text" class="form-control" autocomplete="off" id="shots">
                        </div>
                        <div class="form-group col-md-4">
                            <label class="col-form-label font-weight-bold">N° Cavidades</label>
                            <input type="text" class="form-control" autocomplete="off" id="cavidade">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light font-weight-bold" data-dismiss="modal">Cancelar</button>
                        <button type="submit" id="btnGuardar" class="btn btn-success font-weight-bold">Salvar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!--FIN del cont principal-->

<?php require_once "vistas/parte_inferior.php" ?>