$(document).ready(function () {

    function showLoading(msg) {
        msg = (msg == "") ? "Loading..." : msg;
        $(".splash").find("h2").text(msg);
        $(".splash").show();
    }
    function hideLoading() {
        $(".splash").hide();
    }

    function alerta(tipo, msg) {
        const Toast = Swal.mixin({
            toast: true,
            position: "top-end",
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            onOpen: (toast) => {
                toast.addEventListener("mouseenter", Swal.stopTimer)
                toast.addEventListener("mouseleave", Swal.resumeTimer)
            }
        })
        Toast.fire({
            type: tipo,
            title: msg
        })
    }

    //botão Sair do sistema
    $(document).on("click", ".sairSistema", function () {
        Swal.fire({
            title: 'Deseja Sair do Sistema ?',
            text: "",
            type: 'question',
            showCancelButton: true,
            confirmButtonColor: '#1cc88a',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Confirmar'
        }).then((result) => {
            if (result.value) {
                window.location.href = "login/";
            }
        })
    });

    //DataTable
    tabelaPreventivas = $("#tabelaPreventivas").DataTable({

        "ajax": {
            "url": "bd/preventivas.php",
            "method": 'POST',
            "data": { opcion: 4 }, //se for preciso enviar algum valor ou dado como paramentro, pode passar assim: {valor: valor} no lugar do 'null'
            "dataSrc": ""
        },
        "columns": [
            { "data": "molde" },
            { "data": "descricao" },
            { "data": "status_preventiva" },
            { "data": "shot_acumulado" },
            { "data": "data_ultima_preventiva" },
            { "data": "num_cavidades" },
            { "data": "num_shots" },
            { "defaultContent": "<div class='text-center'><div class='btn-group'><button class='btn btn-info btnVisualizarCliente'>Visualizar</button><button class='btn btn-warning btnAgendarCliente'>Agendar</button></div></div>" }
        ],
        "columnDefs": [
            {
                'targets': [2],
                'render': function (data, type, row, meta) {
                    if (row.status_preventiva == 'REALIZADO') {
                        var status_prev = "<div class='text-center'><h5 class='badge badge-pill badge-success'>" + row.status_preventiva + "</h5></div>";
                    } else {
                        var status_prev = "<div class='text-center'><h5 class='badge badge-pill badge-warning'>" + row.status_preventiva + "</h5></div>";
                    }
                    return status_prev;
                }
            },
        ],
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros",
            "zeroRecords": "Não foi encontrado resultados",
            "info": "Mostrando registros de _START_ a _END_ de um total de _TOTAL_ registros",
            "infoEmpty": "Mostrando registros de 0 a 0 de um total de 0 registros",
            "infoFiltered": "(filtrado de um total de _MAX_ registros)",
            "sSearch": "Buscar:",
            "oPaginate": {
                "sFirst": "Primeiro",
                "sLast": "Último",
                "sNext": "Seguinte",
                "sPrevious": "Anterior"
            },
            "sProcessing": "Processando...",
        }
    });
    //DataTable
    tabelaMolde = $("#tabelaMolde").DataTable({

        "ajax": {
            "url": "bd/preventivas.php",
            "method": 'POST',
            "data": { opcion: 4 }, //se for preciso enviar algum valor ou dado como paramentro, pode passar assim: {valor: valor} no lugar do 'null'
            "dataSrc": ""
        },
        "columns": [
            { "data": "molde" },
            { "data": "descricao" },
            { "data": "status_preventiva" },
            { "data": "shot_acumulado" },
            { "data": "data_ultima_preventiva" },
            { "data": "num_cavidades" },
            { "data": "num_shots" },
            { "defaultContent": "<div class='text-center'><div class='btn-group'><button class='btn btn-primary btnEditarMolde'>Editar</button><button class='btn btn-danger btnAgendarCliente'>Excluir</button></div></div>" }
        ],
        "columnDefs": [
            {
                'targets': [2],
                'render': function (data, type, row, meta) {
                    if (row.status_preventiva == 'REALIZADO') {
                        var status_prev = "<div class='text-center'><h5 class='badge badge-pill badge-success'>" + row.status_preventiva + "</h5></div>";
                    } else {
                        var status_prev = "<div class='text-center'><h5 class='badge badge-pill badge-warning'>" + row.status_preventiva + "</h5></div>";
                    }
                    return status_prev;
                }
            },
        ],
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros",
            "zeroRecords": "Não foi encontrado resultados",
            "info": "Mostrando registros de _START_ a _END_ de um total de _TOTAL_ registros",
            "infoEmpty": "Mostrando registros de 0 a 0 de um total de 0 registros",
            "infoFiltered": "(filtrado de um total de _MAX_ registros)",
            "sSearch": "Buscar:",
            "oPaginate": {
                "sFirst": "Primeiro",
                "sLast": "Último",
                "sNext": "Seguinte",
                "sPrevious": "Anterior"
            },
            "sProcessing": "Processando...",
        }
    });
    /* Tabela Diario*/
    tabelaDiario = $("#tabelaDiario").DataTable({

        "ajax": {
            "url": "bd/diario.php",
            "method": 'POST',
            "data": { opcion: 4 }, //se for preciso enviar algum valor ou dado como paramentro, pode passar assim: {valor: valor} no lugar do 'null'
            "dataSrc": ""
        },
        "columns": [
            { "data": "molde" },
            { "data": "descricao" },
            { "data": "data_producao" },
            { "data": "qtde_produzida" },
            { "data": "shot_acumulado" },
            { "data": "num_cavidades" },
            { "defaultContent": "<div class='text-center'><div class='btn-group'><button class='btn btn-primary btnEditarCliente'>Editar</button><button class='btn btn-danger btnAgendarCliente'>Excluir</button></div></div>" }
        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros",
            "zeroRecords": "Não foi encontrado resultados",
            "info": "Mostrando registros de _START_ a _END_ de um total de _TOTAL_ registros",
            "infoEmpty": "Mostrando registros de 0 a 0 de um total de 0 registros",
            "infoFiltered": "(filtrado de um total de _MAX_ registros)",
            "sSearch": "Buscar:",
            "oPaginate": {
                "sFirst": "Primeiro",
                "sLast": "Último",
                "sNext": "Seguinte",
                "sPrevious": "Anterior"
            },
            "sProcessing": "Processando...",
        }
    });
      /* miniTabela Diario Cronograma Geral*/
      tabelaDiario = $("#minitabelaDiario").DataTable({

        "ajax": {
            "url": "bd/diario.php",
            "method": 'POST',
            "data": { opcion: 4 }, //se for preciso enviar algum valor ou dado como paramentro, pode passar assim: {valor: valor} no lugar do 'null'
            "dataSrc": ""
        },
        "columns": [
            { "data": "molde" },
            { "data": "qtde_produzida" },
            { "data": "data_producao" },
            ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros",
            "zeroRecords": "Não foi encontrado resultados",
            "info": "Mostrando registros de _START_ a _END_ de um total de _TOTAL_ registros",
            "infoEmpty": "Mostrando registros de 0 a 0 de um total de 0 registros",
            "infoFiltered": "(filtrado de um total de _MAX_ registros)",
            "sSearch": "Buscar:",
            "oPaginate": {
                "sFirst": "Primeiro",
                "sLast": "Último",
                "sNext": "Seguinte",
                "sPrevious": "Anterior"
            },
            "sProcessing": "Processando...",
        }
    });
    //botão adicionar
    $("#btnAdicionar").click(function () {
        $("#formPreventivas").trigger("reset");
        $(".modal-header").css("background-color", "#1cc88a");
        $(".modal-header").css("color", "white");
        $(".modal-title").text("Novo Molde");
        $("#modalCRUD").modal("show");
        id_cliente = null;
        opcion = 1; //alta
    });
    //botão adicionar Registro Diario
    $("#btnAdicionarDiario").click(function () {
        $("#formDiario").trigger("reset");
        $(".modal-header").css("background-color", "#1cc88a");
        $(".modal-header").css("color", "white");
        $(".modal-title").text("Novo Registro Diário");
        $("#modalCRUDDiario").modal("show");
        id_cliente = null;
        opcion = 1; //alta
    });
    //botão adicionar Molde
    $("#btnAdicionarMolde").click(function () {
        $("#formMolde").trigger("reset");
        $(".modal-header").css("background-color", "#1cc88a");
        $(".modal-header").css("color", "white");
        $(".modal-title").text("Novo Molde");
        $("#modalCRUDMolde").modal("show");
        id_cliente = null;
        opcion = 1; //alta
    });
    var fila; //capturar a fila para editar ou excluir o registro da tabela.

    //botão EDITAR    
    $(document).on("click", ".btnEditarCliente", function () {
        fila = $(this).closest("tr");
        id_cliente = parseInt(fila.find('td:eq(0)').text());
        nome = fila.find('td:eq(1)').text();
        codigo_cliente = fila.find('td:eq(2)').text();

        $("#nome").val(nome);
        $("#codigo_cliente").val(codigo_cliente);
        opcion = 2; //editar

        $(".modal-header").css("background-color", "#1cc88a");
        $(".modal-header").css("color", "white");
        $(".modal-title").text("Editar Molde");
        $("#modalCRUD").modal("show");

    });
    //botão EDITAR Diario   
    $(document).on("click", ".btnEditarCliente", function () {
        fila = $(this).closest("tr");
        molde = parseInt(fila.find('td:eq(0)').text());
        descricao = fila.find('td:eq(1)').text();
        data = fila.find('td:eq(2)').text();
        qtd_pecas_produzidas = fila.find('td:eq(3)').text();
        shots = fila.find('td:eq(4)').text();
        cavidade = fila.find('td:eq(5)').text();

        $("#molde_").val(molde);
        $("#descricao").val(descricao);
        $("#data").val(data);
        $("#qtd").val(qtd_pecas_produzidas);
        $("#shots").val(shots);
        $("#cavidade").val(cavidade);
        opcion = 2; //editar

        $(".modal-header").css("background-color", "#1cc88a");
        $(".modal-header").css("color", "white");
        $(".modal-title").text("Editar Registro");
        $("#modalCRUDDiario").modal("show");

    });
    //botão Agendar
    $(document).on("click", ".btnAgendarCliente", function () {
        fila = $(this).closest("tr");
        molde = fila.find('td:eq(0)').text();
        qtd_acumulada = parseInt(fila.find('td:eq(3)').text());
        $("#molde_2").val(molde);
        $("#qtd_acumulada").val(qtd_acumulada);
        opcion = 1; //editar

        $(".modal-header").css("background-color", "#1cc88a");
        $(".modal-header").css("color", "white");
        $(".modal-title").text("Agendar Molde");
        $("#modalCRUDAgendar").modal("show");

    });
    //botão Visualizar
    $(document).on("click", ".btnVisualizarCliente", function () {
        fila = $(this).closest("tr");
        molde = fila.find('td:eq(0)').text();
        descricao = fila.find('td:eq(1)').text();
        status = fila.find('td:eq(2)').text();
        qtd_acumulada = parseInt(fila.find('td:eq(3)').text());
        data = fila.find('td:eq(4)').text();
        total_shots = fila.find('td:eq(5)').text();
        $("#molde_").val(molde);
        $("#descricao").val(descricao);
        $("#status").val(status);
        $("#qtd_shot_acumulada").val(qtd_acumulada);
        $("#data").val(data);
        $("#total_shots").val(total_shots);
        opcion = 1; //editar

        $(".modal-header").css("background-color", "#1cc88a");
        $(".modal-header").css("color", "white");
        $(".modal-title").text("Visualização");
        $("#modalCRUD").modal("show");

    });
    //botão Editar Molde
    $(document).on("click", ".btnEditarMolde", function () {
        fila = $(this).closest("tr");
        molde = fila.find('td:eq(0)').text();
        descricao = fila.find('td:eq(1)').text();
        status = fila.find('td:eq(2)').text();
        qtd_acumulada = parseInt(fila.find('td:eq(3)').text());
        data = fila.find('td:eq(4)').text();
        total_shots = fila.find('td:eq(5)').text();
        $("#molde_").val(molde);
        $("#descricao").val(descricao);
        $("#status").val(status);
        $("#qtd_shot_acumulada").val(qtd_acumulada);
        $("#data").val(data);
        $("#total_shots").val(total_shots);
        opcion = 1; //editar

        $(".modal-header").css("background-color", "#1cc88a");
        $(".modal-header").css("color", "white");
        $(".modal-title").text("Editar Molde");
        $("#modalCRUDMolde").modal("show");

    });
    //botão Excluir
    $(document).on("click", ".btnExcluirCliente", function () {
        fila = $(this);
        id_cliente = parseInt($(this).closest("tr").find('td:eq(0)').text());
        opcion = 3 //Excluir
        Swal.fire({
            title: 'Excluir ' + $(this).closest("tr").find('td:eq(1)').text() + ' ?',
            text: "Cóodigo: " + $(this).closest("tr").find('td:eq(2)').text(),
            type: 'error',
            showCancelButton: true,
            confirmButtonColor: '#1cc88a',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Confirmar'
        }).then((result) => {
            if (result.value) {

                $.ajax({
                    url: "bd/preventivas.php",
                    type: "POST",
                    dataType: "json",
                    data: { opcion: opcion, id_cliente: id_cliente },
                    beforeSend: function () {
                        showLoading('Aguarde, carregando ...');
                    },
                    success: function (data) {
                        tabelaPreventivas.ajax.reload(null, false);
                        alerta("success", "O cliente selecionado foi excluído com sucesso!");
                        hideLoading();
                    }
                });

            }
        })
    });

    //botão salvar
    $("#formClienteAgendar").submit(function (e) {
        e.preventDefault();
        molde = $.trim($("#molde_").val());
        console.log(molde);
        qtd_acumulada = $.trim($("#qtd_acumulada").val());
        data = $.trim($("#data").val());
        $.ajax({
            url: "bd/agendar.php",
            type: "POST",
            dataType: "json",
            data: { molde: molde, qtd_acumulada: qtd_acumulada, data: data, opcion: 1 },
            beforeSend: function () {
                showLoading('Aguarde, carregando ...');
            },
            success: function (data) {
                if (opcion == 1) {
                    tabelaPreventivas.ajax.reload(null, false);
                    alerta("success", "Cliente cadastrado com Sucesso!");
                } else {
                    tabelaPreventivas.ajax.reload(null, false);
                    alerta("success", "Dados atualizados com Sucesso!");
                }
                hideLoading();
            }
        });
        $("#modalCRUDAgendar").modal("hide");
    });





});