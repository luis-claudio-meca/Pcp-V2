<?php
include_once '../bd/conexion.php';
$objeto = new Conexion();
$conexion = $objeto->Conectar();

$molde = (isset($_POST['molde'])) ? $_POST['molde'] : '';

$descricao = (isset($_POST['descricao'])) ? $_POST['descricao'] : '';
$data = (isset($_POST['data'])) ? $_POST['data'] : '';
$qtd_pecas_produzidas = (isset($_POST['qtd_pecas_produzidas'])) ? $_POST['qtd_pecas_produzidas'] : '';
$shots = (isset($_POST['shots'])) ? $_POST['shots'] : '';
$cavidade = (isset($_POST['cavidade'])) ? $_POST['cavidade'] : '';
$opcion = (isset($_POST['opcion'])) ? $_POST['opcion'] : '';
$id_cliente = (isset($_POST['id_cliente'])) ? $_POST['id_cliente'] : '';

switch($opcion){
    case 1: //alta
        $consulta = "INSERT INTO agendar (molde,qtd_acumulada,data) VALUES('$molde','$qtd_acumulada','$data') ";			
        $resultado = $conexion->prepare($consulta);
        $resultado->execute(); 

        $consulta = "SELECT id_cliente, nome, codigo_cliente FROM cliente ORDER BY id_cliente DESC LIMIT 1";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break;
    case 2: //modificación
        $consulta = "UPDATE cliente SET nome='$nome', codigo_cliente='$codigo_cliente' WHERE id_cliente='$id_cliente' ";		
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();        
        
        $consulta = "SELECT id_cliente, nome, codigo_cliente FROM cliente WHERE id_cliente='$id_cliente' ";       
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break;        
    case 3://baja
        $consulta = "DELETE FROM cliente WHERE id_cliente='$id_cliente' ";		
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        
        $consulta = "SELECT * FROM cliente";       
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break;
    case 4://baja
        $consulta = "SELECT preventivas.molde,preventivas.descricao,DATE_FORMAT(diario.data_producao,'%d/%m/%Y') AS 'data_producao',diario.qtde_produzida,preventivas.shot_acumulado,preventivas.num_cavidades FROM diario INNER JOIN preventivas ON diario.preventivas = preventivas.molde";       
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);                           
            break;        
}

print json_encode($data, JSON_UNESCAPED_UNICODE); //enviar el array final en formato json a JS
$conexion = NULL;
