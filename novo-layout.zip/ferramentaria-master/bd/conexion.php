<?php 
class Conexion{	  
    public static function Conectar() {        
        define('servidor', '185.209.179.96');
        define('nome_bd', 'ferramentaria');
        define('usuario', 'tutiplast');
        define('password', 'tut!l@bs#');					        
        $opciones = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8');			
        try{
            $conexion = new PDO("mysql:host=".servidor."; dbname=".nome_bd, usuario, password, $opciones);			
            return $conexion;
        }catch (Exception $e){
            die("Erro na Conexão pode ser: ". $e->getMessage());
        }
    }
}