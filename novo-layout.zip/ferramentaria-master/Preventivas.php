<?php require_once "vistas/parte_superior.php" ?>

<!--INICIO del cont principal-->
<div class="container">

    <div class="d-none d-xl-block">
        <h2 class="font-weight-bold text-center">Cronograma Geral</h2>
    </div>
    <div class="d-none d-lg-block d-xl-none">
        <h3 class="rounded mx-auto d-block font-weight-bold text-center">Clientes</h3>
    </div>
    <div class="d-none d-md-block d-lg-none">
        <h4 class="rounded mx-auto font-weight-bold text-center">Clientes</h4>
    </div>
    <div class="d-none d-sm-block d-md-none">
        <h5 class="rounded mx-auto d-block font-weight-bold text-center">Clientes</h5>
    </div>
    <div class="d-block d-sm-none">
        <h5 class="rounded mx-auto d-block font-weight-bold text-center">Clientes</h5>
    </div>


    <div class="container">
        <div class="row">
            <div class="col-lg-12">
              <button style="float:right" id="btnAdicionar" type="button" class="btn btn-success shadow-sm lift o-hidden" data-toggle="modal"><i class="fas fa-plus"></i>Adicionar Novo</button>
            </div>
            
        </div>   
    </div>
    <br>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card shadow mb-4">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="tabelaPreventivas" class="table table-striped table-bordered table-condensed" style="width:100%">
                                <thead class="text-center">
                                    <tr>
                                        <th>Molde</th>
                                        <th>Descrição</th>
                                        <th>Status</th>
                                        <th>Shots Acumulados</th>
                                        <th>Data</th>
                                        <th>Nº de Cavidadse</th>
                                        <th>Total Shots</th>
                                        <th>Visualizar/Agendar</th>
                                    </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--Modal para Visualizacao CRUD-->
    <div class="modal fade" id="modalCRUD" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" data-backdrop="static" data-keyboard="false" aria-hidden="true">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="formPreventivas">
                    <div class="modal-body row">
                        <div class="form-group col-md-4">
                            <label class="col-form-label font-weight-bold">Molde:</label>
                            <input type="text" class="form-control" autocomplete="off" name="molde" id="molde_">
                        </div>
                        <div class="form-group col-md-4">
                            <label class="col-form-label font-weight-bold">Descricao</label>
                            <input type="text" class="form-control" autocomplete="off" id="descricao">
                        </div>
                        <div class="form-group col-md-4">
                            <label class="col-form-label font-weight-bold">status</label>
                            <input type="text" class="form-control" autocomplete="off" id="status">
                        </div>
                        <div class="form-group col-md-4">
                            <label class="col-form-label font-weight-bold">Qtd Shot Acumulada</label>
                            <input type="text" class="form-control" autocomplete="off" id="qtd_shot_acumulada">
                        </div>
                        <div class="form-group col-md-4">
                            <label class="col-form-label font-weight-bold">Data</label>
                            <input type="text" class="form-control" autocomplete="off" id="data">
                        </div>
                        <div class="form-group col-md-4">
                            <label class="col-form-label font-weight-bold">Total Shots</label>
                            <input type="text" class="form-control" autocomplete="off" id="total_shots">
                        </div>
                    </div>
                    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="card shadow mb-4">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="minitabelaDiario" class="table table-striped table-bordered table-condensed" style="width:100%">
                                <thead class="text-center">
                                    <tr>
                                        <th>Molde</th>
                                        <th>Qtde Porduzida</th>
                                        <th>Data</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light font-weight-bold" data-dismiss="modal">Cancelar</button>
                        <button type="submit" id="btnGuardar" class="btn btn-success font-weight-bold">Salvar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--Modal Agendar para CRUD-->
    <div class="modal fade" id="modalCRUDAgendar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" data-backdrop="static" data-keyboard="false" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="formClienteAgendar">
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="col-form-label font-weight-bold">Molde:</label>
                            <input type="text" class="form-control" autocomplete="off" name="molde3" id="molde_2">
                        </div>
            
                        <div class="form-group">
                            <label class="col-form-label font-weight-bold">Qtd Shot Acumulada</label>
                            <input type="text" class="form-control" autocomplete="off" name="qtd_acumulada" id="qtd_acumulada">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label font-weight-bold">Data</label>
                            <input type="date" class="form-control" autocomplete="off" name="data" id="data">
                        </div>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light font-weight-bold" data-dismiss="modal">Cancelar</button>
                        <button type="submit"  class="btn btn-success font-weight-bold">Salvar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!--FIN del cont principal-->

<?php require_once "vistas/parte_inferior.php" ?>